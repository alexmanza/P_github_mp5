package com.iesebre;

import org.testng.annotations.Test;

public class DecimalBinarioTest {
    @Test
    public static void main(String[] args) {
        int[] decimales = { 0, 2, 5, 50, 120, 1023, 51, 52, 60, 100, 53, 54, 55, 56, 57, 16, 17 };

        for (int decimal : decimales) {
            System.out.println("Convirtiendo decimal a binario el número " + decimal);
            System.out.println("Manual: " + convertirDecimalABinarioManual(decimal));
            System.out.println("Usando funciones: " + convertirDecimalABinario(decimal));
        }
    }

    public static String convertirDecimalABinario(long decimal) {
        return Long.toBinaryString(decimal);
    }

    public static String convertirDecimalABinarioManual(long decimal) {
        if (decimal <= 0) {
            return "0";
        }
        StringBuilder binario = new StringBuilder();
        while (decimal > 0) {
            short residuo = (short) (decimal % 2);
            decimal = decimal / 2;
            // Insertar el dígito al inicio de la cadena
            binario.insert(0, String.valueOf(residuo));
        }
        return binario.toString();
    }
}